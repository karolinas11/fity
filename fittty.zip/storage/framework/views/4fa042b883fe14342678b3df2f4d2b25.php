<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <?php echo $__env->yieldContent('styles'); ?>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <?php echo $__env->yieldContent('scriptsTop'); ?>
    <!-- Scripts -->

</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    Fity Test
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto ms-auto">
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('show-add-recipe')); ?>">Dodaj recept</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('show-add-user')); ?>">Dodaj korisnika</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('show-add-foodstuff')); ?>">Dodaj namirnicu</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('show-add-foodstuff-category')); ?>">Dodaj kategoriju namirnice</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('show-recipes-list')); ?>">Lista recepata</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('show-foodstuffs-list')); ?>">Lista namirnica</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('show-users-list')); ?>">Lista korisnika</a></li>

                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

<?php echo $__env->yieldContent('scriptsBottom'); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\project-fity\resources\views/layouts/app.blade.php ENDPATH**/ ?>