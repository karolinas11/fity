<?php $__env->startSection('content'); ?>
    <div class="container d-flex mt-5">
        <div class="col-4">
            <h3>Dodaj pitanje</h3>
            <button type="button" class="btn btn-primary mt-2 add-question-btn">Prikaži pitanje</button>
            <div class="new-option-container add-question-container mt-4" style="display: none;">
                <input type="text" id="new_pitanje" class="form-control mb-2" placeholder="unesite pitanje...">
                <input type="text" id="new_type" class="form-control mb-2" placeholder="unesite tip pitanja(value,text,date,select....)">
                <input type="text" id="new_id" class="form-control mb-2" placeholder="unesite njegov id,name">
                <textarea name="description" id="new_description" cols="30" rows="10"></textarea>
                <button type="button" class="btn btn-success mt-2 add-question">Dodaj pitanje</button>
            </div>
        </div>
        <div class="col-4">
            <h3>Izbrisi pitanje</h3>
            <button type="button" class="btn btn-danger mt-2 delete-question-btn" >Izbrisi željeno pitanje</button>
            <div class="new-option-container delete-question-container mt-4" style="display: none;">
                <select name="questions" id="questions" class="form-select">
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option data-question-id="<?php echo e($question->id); ?>" value="<?php echo e($question->name_question); ?>"><?php echo e($question->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="button" class="btn btn-danger mt-2 delete-question">Izbrisi pitanje</button>
            </div>
        </div>
       <div class="col-4">
           <h3>Izmeni pitanje</h3>
           <select id="edit-questions" name="edit-questions" class="form-select">
               <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option  data-question-id="<?php echo e($question->id); ?>" data-question-type="<?php echo e($question->type); ?>" value="<?php echo e($question->name_question); ?>"><?php echo e($question->title); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
           <button type="button" class="btn btn-dark mt-2 edit-question-btn">Izmeni pitanja</button>
           <div class="new-option-container edit-question-container mt-4" style="display:none;">
                <input type="text" id="edit-question-text" class="form-control mb-2" placeholder="pitanje">
                <input type="text" id="edit-question-type" class="form-control mb-2" placeholder="tip pitanja(select,input)">
                <input type="text" id="edit-question-name" class="form-control mb-2" placeholder="name_question za id name">
               <textarea name="description" id="edit-question-description" cols="30" rows="10"></textarea>
                <button type="submit" class="btn btn-success" id="update-question">Izmenite</button>
           </div>
       </div>
    </div>
    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="question-<?php echo e($question->id); ?>" class="container mt-5">
                <b>Naslov:</b> <label for="<?php echo e($question->id); ?>" class="form-label"><?php echo e($question->title); ?></label><br>
                <?php if($question->type === 'select' || $question->type === 'value'): ?>
                    <select name="<?php echo e($question->name_question); ?>" id="<?php echo e($question->name_question); ?>" class="form-select main-select">
                        <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option data-subtitle="<?php echo e($option->subtitle); ?>" data-title="<?php echo e($option->value); ?>" data-name="<?php echo e($option->name_option); ?>">
                                <p id="option-title"><?php echo e($option->value); ?></p> |
                                <p id="option-subtitle"><?php echo e($option->subtitle); ?></p> |
                                <p id="option-name"><?php echo e($option->name_option); ?></p>
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <button type="button" class="btn btn-primary mt-2 add-option-btn" data-question-id="<?php echo e($question->id); ?>">
                        Dodaj opciju
                    </button>

                    <button type="button" class="btn btn-danger mt-2 delete-option-btn">Izbrisi opciju</button>
                    <button type="button" class="btn btn-dark mt-2 update-option-btn">Izmeni opciju</button>
                    <div class="new-option-container update-option-container mt-2" style="display:none;">
                        <p class="mt-4">Izaberi sta zelis da izmenis!</p>
                        <select data-question-id="<?php echo e($question->id); ?>" name="<?php echo e($question->name_question); ?>" id="<?php echo e($question->name_question); ?>" class="form-select mb-4">
                            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option data-option-id="<?php echo e($option->id); ?>" data-title="<?php echo e($option->value); ?>" data-subtitle="<?php echo e($option->subtitle); ?>" data-name="<?php echo e($option->name_option); ?>">
                                    <p id="option-title"><?php echo e($option->value); ?></p> |
                                    <p id="option-subtitle"><?php echo e($option->subtitle); ?></p> |
                                    <p id="option-name"> <?php echo e($option->name_option); ?></p>
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <button type="submit" class="btn btn-dark mt-2 open">Popuni inpute</button>
                        <input id="id-option" type="text" class="form-control">
                        <input type="text" id="title_option" class="form-control">
                        <input type="text" id="subtitle_option" class="form-control">
                        <input type="text" id="name_option" class="form-control">
                        <button type="button" class="btn btn-success mt-2 update-option" data-question-id="<?php echo e($question->id); ?>">Sacuvaj izmene</button>
                    </div>

                    <div class="new-option-container create-container mt-2" style="display: none;">
                        <input type="text" class="form-control new-title-input" placeholder="Naziv nove opcije">
                        <input type="text" class="form-control new-subtitle-input" placeholder="Unesite subtitle">
                        <input type="text" class="form-control new-name-input" placeholder="Unesite type">
                        <button type="button" class="btn btn-success mt-2 save-option-btn" data-question-id="<?php echo e($question->id); ?>">
                            Sačuvaj opciju
                        </button>
                    </div>

                    <div class="new-option-container delete-container mt-2" style="display: none;">
                        <select name="<?php echo e($question->name_question); ?>" id="<?php echo e($question->name_question); ?>" class="form-select">
                            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($option->name_option); ?>"><?php echo e($option->value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <button type="button" class="btn btn-danger mt-2 remove-option-btn" data-question-id="<?php echo e($question->id); ?>">
                            Sačuvaj promene
                        </button>
                    </div>

                <?php else: ?>
                    <input type="<?php echo e($question->type); ?>" class="form-control" name="<?php echo e($question->name_question); ?>">
                <?php endif; ?>

            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptsBottom'); ?>
    <script src="<?php echo e(asset('js/script-question-option.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project-fity\resources\views/boarding-question.blade.php ENDPATH**/ ?>