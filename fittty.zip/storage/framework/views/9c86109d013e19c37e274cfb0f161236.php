<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('add-recipe')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name">Naziv recepta</label>
            <input type="text" name="name">
        </div>

        <div>
            <label for="description">Upustvo i opis</label>
            <input type="text" name="description">
        </div>

        <div>
            <label for="short_description">Kratki opis</label>
            <input type="text" name="short_description">
        </div>

        <div>
            <label>Namirnica</label>
            <select name="foodstuff_id">
                <?php $__currentLoopData = $foodstuffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foodstuff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($foodstuff->id); ?>"><?php echo e($foodstuff->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label for="amount">Količina</label>
            <input type="number" name="amount">
        </div>

        <div>
            <button type="submit">Pošalji</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project-fity\resources\views/create-recipe.blade.php ENDPATH**/ ?>