<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('add-foodstuff')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name">Naziv namirnice</label>
            <input type="text" name="name">
        </div>

        <div>
            <label>Kategorija namirnice</label>
            <select name="foodstuff_category_id">
                <?php $__currentLoopData = $foodstuffCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foodstuffCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($foodstuffCategory->id); ?>"><?php echo e($foodstuffCategory->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label for="amount">Količina</label>
            <input type="number" name="amount">
        </div>

        <div>
            <label for="measurement_unit">Jedinica mere</label>
            <input type="text" name="measurement_unit">
        </div>

        <div>
            <label for="calories">Kalorije</label>
            <input type="number" name="calories">
        </div>

        <div>
            <label for="proteins">Proteini</label>
            <input type="number" name="proteins">
        </div>

        <div>
            <label for="fats">Masti</label>
            <input type="number" name="fats">
        </div>

        <div>
            <label for="carbohydrates">Ugljeni hidrati</label>
            <input type="number" name="carbohydrates">
        </div>

        <div>
            <button type="submit">Pošalji</button>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project-fity\resources\views/create-foodstuff.blade.php ENDPATH**/ ?>