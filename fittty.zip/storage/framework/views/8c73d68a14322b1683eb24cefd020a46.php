<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('add-foodstuff-category')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name">Naziv kategorije:</label>
            <input type="text" name="name">
        </div>

        <div>
            <button type="submit">Pošalji</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project-fity\resources\views/create-foodstuff-category.blade.php ENDPATH**/ ?>